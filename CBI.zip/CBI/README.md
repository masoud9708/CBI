# VISA-CARD

Pkg update

Pkg upgrade

Pkg install python

Pkg install python2

Pkg install git 

Pkg install  php

git clone https://github.com/Kasper-Dz/VISA-CARD.git

cd VISA-CARD

ls

chmod +x Card.sh

bash Card.sh

بعدها تضع رقم 1

بعدها تضع اي رقم 

كان معكم 

# MRX_FR13NDS
